var cheat=[]
var h;
var cam;
var charcterx=[]
var charctery=[]
var gold=[]
var thieve=[]
 charcterx[1]=0
 charctery[1]=0
 charcterx[2]=0
 charctery[2]=0
 var s= false
 var w= false
 var d= false
 var a= false 
 var points=0
var highlight=false
var music;
var musica="6634352261201920.mp3"
var musicb="4730043755921408.mp3"
 let mute;
var mo=true
 //createCanvas(500,500)
function setup() {frameRate(14+round(points/3));
                music = loadSound(musicb,playmusic)
  h = getItem('highscore');

   if (h === undefined) {
     h = 0;
   }    
   gold[1]=round(random(40,320)/40)*40
  gold[2]=round(random(40,320)/40)*40
  createCanvas(400, 500);
  thieve=[0,round(random(40,320)/40)*40,round(random(40,320)/40)*40,round(random(40,320)/40)*40,round(random(40,320)/40)*40]
                  mute = createButton('mute on off');
  mute.position(0, 0);
  mute.mousePressed(muted);
//storeItem('highscore', 0);
}
function muted(){if(mo){music.stop();mo=false}else{music.loop();mo=true}}
function playmusic(){music.loop();}
function draw() { 
bg();//hatbegin();
  t();
  hat();
  mobboss()
if(charcterx[1]==thieve[1] && charctery[1]==thieve[2] || charcterx[1]==thieve[3] && charctery[1]==thieve[4]){points=0
  frameRate(14);
}
if(charcterx[1]==gold[1] && charctery[1]==gold[2]){points=points+1;thieve=[0,round(random(40,320)/40)*40,round(random(40,320)/40)*40,round(random(40,320)/40)*40,round(random(40,320)/40)*40]
//if(points<6){
 frameRate(14+round(points/4));//}else{frameRate(12);}
 while(charcterx[1]==gold[1] && charctery[1]==gold[2] 
 || gold[1]==thieve[1] && gold[2]==thieve[2] 
 || gold[1]==thieve[3] && gold[2]==thieve[4]  
 || w==true && charctery[1]>=thieve[2] && charcterx[1]== thieve[1]
 || s==true && charctery[1]<=thieve[2] && charcterx[1]== thieve[1]
 || a==true && charcterx[1]>=thieve[1] && charctery[1]== thieve[2]
 || d==true && charcterx[1]<=thieve[1] && charctery[1]== thieve[2]
 || w==true && charctery[1]>=thieve[4] && charcterx[1]== thieve[3]
 || s==true && charctery[1]<=thieve[4] && charcterx[1]== thieve[3]
 || a==true && charcterx[1]>=thieve[3] && charctery[1]== thieve[4]
 || d==true && charctery[1]<=thieve[3] && charctery[1]== thieve[4]
 || w==true && charcterx[1]== gold[1]
 || s==true && charcterx[1]== gold[1]
 || a==true && charctery[1]== gold[2]
 || d==true && charctery[1]== gold[2]
 ){gold[1]=round(random(40,320)/40)*40
  gold[2]=round(random(40,320)/40)*40;thieve=[0,round(random(40,320)/40)*40,round(random(40,320)/40)*40,round(random(40,320)/40)*40,round(random(40,320)/40)*40]}}

fill("yellow")
rect(gold[1],gold[2],40,40);


if(key=="s" && charctery[1]!=360 || key=="ArrowDown" && charctery[1]!=360){s=true;w=false;a=false;d=false;}
if(key=="w" && charctery[1]!=0 || key=="ArrowUp" && charctery[1]!=0){s=false;w=true;a=false;d=false;}
if(key=="d" && charcterx[1]!=360 || key=="ArrowRight" && charcterx[1]!=360){s=false;w=false;a=false;d=true;}
if(key=="a" && charcterx[1]!=0 || key=="ArrowLeft" && charcterx[1]!=0){s=false;w=false;a=true;d=false;}
// if(s==true){
// charctery[2]=charctery[2]+(20+round(points/10)*10*1.5)}
// if(w==true){
// charctery[2]=charctery[2]-(20+round(points/10)*10*1.5)}
// if(d==true){
// charcterx[2]=charcterx[2]+(20+round(points/10)*10*1.5)}
// if(a==true){
// charcterx[2]=charcterx[2]-(20+round(points/10)*10*1.5)}
  if(s==true){
charctery[2]=charctery[2]+(20)}
if(w==true){
charctery[2]=charctery[2]-(20)}
if(d==true){
charcterx[2]=charcterx[2]+(20)}
if(a==true){
charcterx[2]=charcterx[2]-(20)}
fill(250,0,0)
textSize(60)
text(points,170,50);
if(round(points/5)>5){}

 if(charctery[2]<=0){charctery[2]=0}
if(charctery[2]>=360){charctery[2]=360}
if(charcterx[2]<=0){charcterx[2]=0}
if(charcterx[2]>=360){charcterx[2]=360}
 charcterx[1]=round(charcterx[2]/40)*40
 charctery[1]=round(charctery[2]/40)*40
//console.log(charcterx)
  // if(charcterx[1]==360){
  //    a=true
  //    }
  // if(charcterx[1]==0){
  //   d=true
  // }
  // if(charctery[1]==360){
  //   w=true
  // }
  //   if(charctery[1]==0){
  //   s=true
  // }
 //World.frameCount;
 //ate
  if(points>h){storeItem('highscore', points);h=points;highlight=true}
  if(points<h){highlight=false}
  fill("black")
  if(highlight){fill("yellow")}
  textSize(20)
  text("highscore="+h,20,430)
if(cheat[0]=="p" && cheat[1]=="=" && cheat[2]=="h"){points=h; frameRate(14+round(h/4));}
  console.log(cheat)
  textSize(50)
  if(frameRate<=14+round(points/4)-10){text("game over",200,200)}
}
function keyReleased() {cheat[0]=cheat[1];
                      cheat[1]=cheat[2];
                      cheat[2]=key
                      
                      
                      }