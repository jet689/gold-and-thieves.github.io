function bg(){
  
  background(150);
for(var x=0;x<=400;x=x+40){
  for(var y=0;y<=360;y=y+40){
    fill(75,50,0)
  rect(x,y,40,40);
 
}}
}