function hat(){
  if(s){
fill("orange");
rect(charcterx[1],charctery[1],40,40);
fill("yellow")
rect(charcterx[1]+15,charctery[1]+10,10,20)
fill("white")
rect(charcterx[1]+15,charctery[1]+30,10,5)}else if(w){
  fill("orange");
rect(charcterx[1],charctery[1],40,40);
fill("yellow")
rect(charcterx[1]+15,charctery[1]+10,10,20)
fill("white")
rect(charcterx[1]+15,charctery[1]+5,10,5)
  
}else if(a){
  fill("orange");
rect(charcterx[1],charctery[1],40,40);
fill("yellow")
rect(charcterx[1]+10,charctery[1]+15,20,10)
fill("white")
rect(charcterx[1]+5,charctery[1]+15,5,10)
  
}else if(d){
  fill("orange");
rect(charcterx[1],charctery[1],40,40);
fill("yellow")
rect(charcterx[1]+10,charctery[1]+15,20,10)
fill("white")
rect(charcterx[1]+30,charctery[1]+15,5,10)
  
}else{
fill("orange");
rect(charcterx[1],charctery[1],40,40);
fill("yellow")
rect(charcterx[1]+15,charctery[1]+10,10,20)
fill("white")
rect(charcterx[1]+15,charctery[1]+30,10,5)}
  
}
function hatbegin(){ 
fill("orange");
rect(charcterx[1],charctery[1],40,40);
fill("yellow")
rect(charcterx[1]+15,charctery[1]+10,10,20)
fill("white")
rect(charcterx[1]+15,charctery[1]+30,10,5)}