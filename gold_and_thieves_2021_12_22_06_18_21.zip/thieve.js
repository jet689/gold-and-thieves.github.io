var m;
function t(){
  
    fill(0)
  rect(thieve[1],thieve[2],40,40)
  rect(thieve[3],thieve[4],40,40)
}
function mobboss(){
m=[0,round(random(40,320)/4)*40,round(random(40,320)/4)*40];
if(m[1]>charcterx[1] && a==true){m[1]-=40}else if(m[2]>charctery[1] && w==true){m[2]-=40} else if(m[1]<charcterx[1] && d==true){m[1]+=40;}else if(m[2]<charctery[1] && s==true){m[2]+=40}
  fill(250,0,0)
  rect(charcterx,charctery,40,40)
}